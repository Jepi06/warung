<?php

namespace App\Models;

use Carbon\CarbonInterface;
use Illuminate\Database\Eloquent\Model;

class OrderItem extends Model
{
    protected $fillable = ['order_id', 'product_id', 'product_name', 'qty', 'price', 'cost'];

    public function order()
    {
        return $this->belongsTo(Order::class);
    }

    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    public function getSubtotalAttribute(): int
    {
        return $this->qty * $this->price;
    }

    public function getProfitAttribute(): int
    {
        return ($this->price - $this->cost) * $this->qty;
    }

    /** Laba penjualan (harga jual - harga beli) untuk pesanan selesai dalam rentang tanggal. */
    public static function profitBetween(CarbonInterface $from, CarbonInterface $to): array
    {
        $items = static::query()
            ->join('orders', 'orders.id', '=', 'order_items.order_id')
            ->where('orders.status', 'completed')
            ->whereBetween('orders.confirmed_at', [$from->copy()->startOfDay(), $to->copy()->endOfDay()])
            ->get(['order_items.price', 'order_items.cost', 'order_items.qty']);

        return [
            'profit' => (int) $items->sum(fn ($i) => ($i->price - $i->cost) * $i->qty),
            'nocost' => $items->where('cost', 0)->count(),
        ];
    }
}
