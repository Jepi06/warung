<?php

namespace App\Http\Controllers\Seller;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\Transaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class KasirController extends Controller
{
    public function index()
    {
        $products = Product::orderBy('name')->get();

        return view('seller.kasir.index', compact('products'));
    }

    /** Penjualan langsung: stok berkurang dan pemasukan tercatat saat itu juga. */
    public function store(Request $request)
    {
        $data = $request->validate([
            'customer_name' => 'nullable|string|max:100',
            'items'         => 'required|array',
            'items.*'       => 'nullable|integer|min:0|max:9999',
        ]);

        $items = collect($data['items'])->map(fn ($q) => (int) $q)->filter(fn ($q) => $q > 0);

        if ($items->isEmpty()) {
            return back()->withErrors(['items' => 'Pilih minimal satu barang.']);
        }

        try {
            $order = DB::transaction(function () use ($data, $items) {
                $products = Product::whereIn('id', $items->keys())->lockForUpdate()->get()->keyBy('id');

                foreach ($items as $id => $qty) {
                    $p = $products->get($id);
                    if (! $p) {
                        throw new \RuntimeException('Ada barang yang sudah tidak tersedia.');
                    }
                    if ($p->stock < $qty) {
                        throw new \RuntimeException("Stok {$p->name} tidak cukup (sisa {$p->stock}).");
                    }
                }

                $name = trim($data['customer_name'] ?? '') ?: 'Pembeli langsung';

                $order = Order::create([
                    'code'          => Str::lower(Str::random(10)),
                    'customer_name' => $name,
                    'status'        => 'completed',
                    'confirmed_at'  => now(),
                    'total'         => 0,
                ]);

                $total = 0;
                foreach ($items as $id => $qty) {
                    $p = $products[$id];

                    OrderItem::create([
                        'order_id'     => $order->id,
                        'product_id'   => $p->id,
                        'product_name' => $p->name,
                        'qty'          => $qty,
                        'price'        => $p->price,
                        'cost'         => $p->cost_price,
                    ]);

                    $p->decrement('stock', $qty);
                    $total += $p->price * $qty;
                }

                $order->update(['total' => $total]);

                Transaction::create([
                    'type'        => 'in',
                    'amount'      => $total,
                    'description' => "Penjualan #{$order->id} - {$name}",
                    'order_id'    => $order->id,
                    'date'        => now()->toDateString(),
                ]);

                return $order;
            });
        } catch (\RuntimeException $e) {
            return back()->withErrors(['items' => $e->getMessage()]);
        }

        return redirect()->route('seller.kasir.index')
            ->with('success', "Penjualan #{$order->id} tercatat: Rp " . number_format($order->total, 0, ',', '.') . '. Stok sudah dikurangi.');
    }
}
