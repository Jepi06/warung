<?php

namespace App\Http\Controllers\Seller;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\Transaction;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        $from = $request->date('from') ?? now()->startOfMonth();
        $to   = $request->date('to') ?? now();

        $range = Transaction::whereBetween('date', [$from->toDateString(), $to->toDateString()]);

        $income  = (clone $range)->where('type', 'in')->sum('amount');
        $expense = (clone $range)->where('type', 'out')->sum('amount');

        // Laba bersih = laba penjualan (jual - beli) dikurangi biaya di luar belanja stok
        $sales      = OrderItem::profitBetween($from, $to);
        $otherCost  = (clone $range)->where('type', 'out')->whereNull('product_id')->sum('amount');
        $salesProfit = $sales['profit'];
        $netProfit   = $salesProfit - $otherCost;
        $noCost      = $sales['nocost'];

        $pendingOrders = Order::where('status', 'pending')->latest()->limit(5)->get();
        $pendingCount  = Order::where('status', 'pending')->count();
        $lowStock      = Product::where('stock', '<=', 5)->orderBy('stock')->limit(8)->get();

        return view('seller.dashboard', compact(
            'from', 'to', 'income', 'expense', 'salesProfit', 'otherCost', 'netProfit', 'noCost',
            'pendingOrders', 'pendingCount', 'lowStock'
        ));
    }
}
