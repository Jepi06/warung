# Warung Laravel

Salin isi folder ini ke proyek Laravel baru (timpa routes/web.php), lalu:

1. Tambahkan ke `.env`:
   SHOP_NAME="Warung Bu Sari"
   SHOP_WA=6281234567890
   SELLER_PASSWORD=ganti-password-ini
2. php artisan migrate  (jalankan lagi jika sebelumnya sudah migrate)
3. php artisan storage:link
4. php artisan serve

Pembeli: http://localhost:8000
Penjual: http://localhost:8000/penjual
