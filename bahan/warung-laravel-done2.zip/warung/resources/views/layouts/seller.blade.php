<!DOCTYPE html>
<html lang="id">
<head>
  @include('partials.head')
  <title>@yield('title', 'Penjual') · {{ config('shop.name') }}</title>
</head>
<body class="min-h-screen bg-kertas font-sans text-ink antialiased">
@php
  $pending = \App\Models\Order::where('status', 'pending')->count();
  $nav = [
    ['seller.dashboard',         'Ringkasan',    'Ringkasan', 'seller.dashboard'],
    ['seller.kasir.index',       'Kasir',        'Kasir',     'seller.kasir.*'],
    ['seller.orders.index',      'Pesanan',      'Pesanan',   'seller.orders.*'],
    ['seller.products.index',    'Barang',       'Barang',    'seller.products.*'],
    ['seller.stock.index',       'Stok & harga', 'Stok',      'seller.stock.*'],
    ['seller.transactions.index','Kas',          'Kas',       'seller.transactions.*'],
  ];
@endphp
  <header class="border-b border-garis bg-white">
    <div class="mx-auto flex max-w-5xl items-center gap-x-6 px-4 py-3">
      <a href="{{ route('seller.dashboard') }}" class="truncate text-lg font-bold tracking-tight text-daun">{{ config('shop.name') }}</a>

      {{-- Menu desktop --}}
      <nav class="hidden flex-1 items-center gap-1 text-sm font-medium md:flex" aria-label="Menu utama">
        @foreach ($nav as [$route, $label, $short, $pattern])
          <a href="{{ route($route) }}"
             class="rounded-lg px-3 py-1.5 {{ request()->routeIs($pattern) ? 'bg-daun text-white' : 'text-ink/70 hover:bg-daun-soft' }}">
            {{ $label }}
            @if ($route === 'seller.orders.index' && $pending > 0)
              <span class="ml-1 rounded-full bg-kunyit px-1.5 text-xs font-bold text-ink">{{ $pending }}</span>
            @endif
          </a>
        @endforeach
      </nav>

      <div class="ml-auto flex items-center gap-4 text-sm">
        <a href="{{ route('shop') }}" class="text-ink/60 hover:text-ink" target="_blank">Lihat toko</a>
        <form method="POST" action="{{ route('seller.logout') }}">@csrf
          <button class="text-ink/60 hover:text-ink">Keluar</button>
        </form>
      </div>
    </div>
  </header>

  <main class="mx-auto max-w-5xl px-4 py-5 pb-24 md:py-6 md:pb-8">
    @include('partials.flash')
    @yield('content')
  </main>

  {{-- Menu bawah di HP --}}
  <nav class="fixed inset-x-0 bottom-0 z-50 grid h-14 grid-cols-6 border-t border-garis bg-white md:hidden" aria-label="Menu utama">
    @foreach ($nav as [$route, $label, $short, $pattern])
      @php $on = request()->routeIs($pattern); @endphp
      <a href="{{ route($route) }}" @if ($on) aria-current="page" @endif
         class="relative flex items-center justify-center text-[11px] font-medium {{ $on ? 'font-bold text-daun' : 'text-ink/55' }}">
        <span class="absolute inset-x-3 top-0 h-0.5 rounded-full {{ $on ? 'bg-daun' : 'bg-transparent' }}"></span>
        {{ $short }}
        @if ($route === 'seller.orders.index' && $pending > 0)
          <span class="absolute right-1.5 top-1.5 min-w-4 rounded-full bg-kunyit px-1 text-center text-[10px] font-bold leading-4 text-ink">{{ $pending }}</span>
        @endif
      </a>
    @endforeach
  </nav>
</body>
</html>
