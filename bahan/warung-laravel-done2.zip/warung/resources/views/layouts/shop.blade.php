<!DOCTYPE html>
<html lang="id">
<head>
  @include('partials.head')
  <title>@yield('title', config('shop.name'))</title>
</head>
<body class="min-h-screen bg-kertas font-sans text-ink antialiased">
  <header class="border-b border-garis bg-white">
    <div class="mx-auto flex max-w-3xl items-center justify-between px-4 py-4">
      <a href="{{ route('shop') }}" class="text-xl font-bold tracking-tight text-daun">{{ config('shop.name') }}</a>
      <a href="{{ route('seller.login') }}" class="text-sm text-ink/60 hover:text-ink">Penjual</a>
    </div>
  </header>
  <main class="mx-auto max-w-3xl px-4 py-6">
    @yield('content')
  </main>
</body>
</html>
