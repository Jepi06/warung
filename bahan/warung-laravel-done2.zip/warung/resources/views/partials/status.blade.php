@php
  $map = [
    'pending'   => ['Menunggu', 'bg-kunyit-soft text-amber-800'],
    'completed' => ['Selesai', 'bg-daun-soft text-daun-dark'],
    'cancelled' => ['Dibatalkan', 'bg-stone-200 text-stone-600'],
  ][$status] ?? [$status, 'bg-stone-200 text-stone-600'];
@endphp
<span class="inline-block rounded-full px-2.5 py-0.5 text-xs font-semibold {{ $map[1] }}">{{ $map[0] }}</span>
