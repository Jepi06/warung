@if (session('success'))
  <div class="mb-4 rounded-lg border border-daun/20 bg-daun-soft px-4 py-3 text-sm text-daun-dark">{{ session('success') }}</div>
@endif
@if ($errors->any())
  <div class="mb-4 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800">
    @foreach ($errors->all() as $e)<div>{{ $e }}</div>@endforeach
  </div>
@endif
