<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="{{ csrf_token() }}">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,400;12..96,500;12..96,600;12..96,700&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script>
tailwind.config = {
  theme: { extend: {
    fontFamily: { sans: ['"Bricolage Grotesque"', 'system-ui', 'sans-serif'] },
    colors: {
      ink: '#17251F', daun: { DEFAULT: '#0E5A4A', dark: '#0A4538', soft: '#E3EFEA' },
      kunyit: { DEFAULT: '#E8A317', soft: '#FBF0D4' }, kertas: '#F6F7F3', garis: '#DDE2DA',
    }
  } }
}
</script>
@verbatim
<style type="text/tailwindcss">
  @layer components {
    .btn { @apply inline-flex items-center justify-center gap-2 rounded-lg px-4 py-2.5 text-sm font-semibold transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-daun disabled:opacity-40 disabled:cursor-not-allowed; }
    .btn-primary { @apply btn bg-daun text-white hover:bg-daun-dark; }
    .btn-ghost { @apply btn border border-garis bg-white text-ink hover:bg-daun-soft; }
    .btn-danger { @apply btn border border-red-200 bg-white text-red-700 hover:bg-red-50; }
    .input { @apply w-full rounded-lg border border-garis bg-white px-3 py-2.5 text-sm text-ink placeholder:text-ink/40 focus:border-daun focus:outline-none focus:ring-2 focus:ring-daun/25; }
    .label { @apply mb-1 block text-sm font-medium text-ink; }
    .panel { @apply rounded-xl border border-garis bg-white; }
    .th { @apply px-4 py-3 text-left text-xs font-semibold text-ink/60; }
    .td { @apply px-4 py-3 text-sm; }
  }
  [x-cloak] { display: none !important; }
  @media (max-width: 767px) {
    .rtable thead { display: none; }
    .rtable, .rtable tbody, .rtable tfoot, .rtable tr { display: block; width: 100%; }
    .rtable tr { padding: .625rem 1rem; }
    .rtable td { display: flex; align-items: center; justify-content: space-between; gap: 1rem; padding: .3rem 0 !important; text-align: right; }
    .rtable td::before { content: attr(data-label); flex-shrink: 0; text-align: left; font-size: .75rem; font-weight: 600; color: rgb(23 37 31 / .55); }
    .rtable td[data-label=""]::before { content: none; }
    .rtable td.rt-title { justify-content: flex-start; text-align: left; font-weight: 600; }
    .rtable td.rt-actions { justify-content: flex-end; }
    .rtable td.rt-empty { display: block; text-align: center; padding: 2rem 0 !important; }
  }
</style>
@endverbatim
<script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.14.1/dist/cdn.min.js"></script>
