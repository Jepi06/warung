@extends('layouts.seller')
@section('title', 'Ringkasan')

@section('content')
@php $rp = fn ($n) => ($n < 0 ? '−' : '') . 'Rp ' . number_format(abs($n), 0, ',', '.'); @endphp

<div class="mb-4 flex flex-wrap items-center justify-between gap-3">
  <h1 class="text-xl font-bold">Ringkasan</h1>
  <a href="{{ route('seller.kasir.index') }}" class="btn-primary">Mulai jual di kasir</a>
</div>

<form method="GET" class="mb-4 grid grid-cols-2 gap-3 sm:flex sm:flex-wrap sm:items-end">
  <div>
    <label class="label" for="from">Dari</label>
    <input id="from" type="date" name="from" value="{{ $from->toDateString() }}" class="input">
  </div>
  <div>
    <label class="label" for="to">Sampai</label>
    <input id="to" type="date" name="to" value="{{ $to->toDateString() }}" class="input">
  </div>
  <button class="btn-ghost col-span-2 sm:col-span-1">Tampilkan</button>
</form>

{{-- Laba bersih --}}
<section class="rounded-xl p-5 text-white {{ $netProfit < 0 ? 'bg-red-800' : 'bg-daun' }}">
  <div class="text-sm text-white/75">Laba bersih</div>
  <div class="mt-1 text-3xl font-bold sm:text-4xl">{{ $rp($netProfit) }}</div>
  <div class="mt-2 text-sm text-white/75">
    Laba penjualan {{ $rp($salesProfit) }} dikurangi biaya lain {{ $rp($otherCost) }}
  </div>
  @if ($noCost > 0)
    <div class="mt-3 rounded-lg bg-white/10 px-3 py-2 text-sm">
      {{ $noCost }} barang terjual belum punya harga beli, jadi laba bisa terlihat lebih besar.
      <a href="{{ route('seller.stock.index') }}" class="font-semibold underline">Isi harga beli</a>
    </div>
  @endif
</section>

<div class="mt-3 grid gap-3 sm:grid-cols-3">
  <div class="panel p-4">
    <div class="text-sm text-ink/60">Pemasukan</div>
    <div class="mt-1 text-xl font-bold text-daun">{{ $rp($income) }}</div>
  </div>
  <div class="panel p-4">
    <div class="text-sm text-ink/60">Pengeluaran</div>
    <div class="mt-1 text-xl font-bold text-red-700">{{ $rp($expense) }}</div>
  </div>
  <div class="panel p-4">
    <div class="text-sm text-ink/60">Selisih kas</div>
    <div class="mt-1 text-xl font-bold {{ $income - $expense < 0 ? 'text-red-700' : '' }}">{{ $rp($income - $expense) }}</div>
    <div class="mt-0.5 text-xs text-ink/50">Pemasukan − pengeluaran, termasuk belanja stok</div>
  </div>
</div>

<div class="mt-6 grid gap-6 lg:grid-cols-2">
  <section>
    <div class="mb-2 flex items-center justify-between">
      <h2 class="font-semibold">Pesanan menunggu ({{ $pendingCount }})</h2>
      <a href="{{ route('seller.orders.index') }}" class="text-sm text-daun hover:underline">Lihat semua</a>
    </div>
    <div class="panel divide-y divide-garis">
      @forelse ($pendingOrders as $o)
        <a href="{{ route('seller.orders.show', $o) }}" class="flex items-center justify-between gap-3 px-4 py-3 hover:bg-daun-soft/50">
          <div class="min-w-0">
            <div class="truncate font-medium">#{{ $o->id }} · {{ $o->customer_name }}</div>
            <div class="text-xs text-ink/50">{{ $o->created_at->diffForHumans() }}</div>
          </div>
          <div class="shrink-0 text-sm font-semibold">Rp {{ number_format($o->total, 0, ',', '.') }}</div>
        </a>
      @empty
        <p class="px-4 py-6 text-center text-sm text-ink/50">Belum ada pesanan baru.</p>
      @endforelse
    </div>
  </section>

  <section>
    <div class="mb-2 flex items-center justify-between">
      <h2 class="font-semibold">Stok menipis</h2>
      <a href="{{ route('seller.stock.index') }}" class="text-sm text-daun hover:underline">Isi stok</a>
    </div>
    <div class="panel divide-y divide-garis">
      @forelse ($lowStock as $p)
        <a href="{{ route('seller.products.edit', $p) }}" class="flex items-center justify-between gap-3 px-4 py-3 hover:bg-daun-soft/50">
          <span class="truncate font-medium">{{ $p->name }}</span>
          <span class="shrink-0 rounded-full px-2.5 py-0.5 text-xs font-semibold {{ $p->stock == 0 ? 'bg-red-100 text-red-700' : 'bg-kunyit-soft text-amber-800' }}">
            {{ $p->stock == 0 ? 'Habis' : 'Sisa ' . $p->stock }}
          </span>
        </a>
      @empty
        <p class="px-4 py-6 text-center text-sm text-ink/50">Semua stok aman.</p>
      @endforelse
    </div>
  </section>
</div>
@endsection
