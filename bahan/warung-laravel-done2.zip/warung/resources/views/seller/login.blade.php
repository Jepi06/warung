<!DOCTYPE html>
<html lang="id">
<head>
  @include('partials.head')
  <title>Masuk penjual · {{ config('shop.name') }}</title>
</head>
<body class="min-h-screen bg-kertas font-sans text-ink antialiased">
  <main class="mx-auto flex min-h-screen max-w-sm flex-col justify-center px-4">
    <h1 class="text-2xl font-bold text-daun">{{ config('shop.name') }}</h1>
    <p class="mb-5 text-sm text-ink/60">Masuk untuk mengelola toko.</p>
    <form method="POST" action="{{ route('seller.login.post') }}" class="panel space-y-4 p-5">
      @csrf
      @if ($errors->any())
        <div class="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-800">{{ $errors->first() }}</div>
      @endif
      <div>
        <label for="password" class="label">Password</label>
        <input id="password" type="password" name="password" autofocus required class="input">
      </div>
      <button class="btn-primary w-full">Masuk</button>
    </form>
    <a href="{{ route('shop') }}" class="mt-4 text-center text-sm text-ink/60 hover:text-ink">Kembali ke toko</a>
  </main>
</body>
</html>
