@extends('layouts.seller')
@section('title', 'Barang')

@section('content')
<div class="mb-4 flex flex-wrap items-center justify-between gap-3">
  <h1 class="text-xl font-bold">Barang</h1>
  <div class="flex gap-2">
    <form method="GET"><input type="search" name="q" value="{{ request('q') }}" placeholder="Cari barang…" class="input"></form>
    <a href="{{ route('seller.products.create') }}" class="btn-primary whitespace-nowrap">Tambah barang</a>
  </div>
</div>

<div class="panel overflow-x-auto">
  <table class="w-full">
    <thead class="border-b border-garis"><tr>
      <th class="th">Barang</th><th class="th">Harga beli</th><th class="th">Harga jual</th><th class="th">Stok</th><th class="th"></th>
    </tr></thead>
    <tbody class="divide-y divide-garis">
      @forelse ($products as $p)
        <tr>
          <td class="td">
            <div class="flex items-center gap-3">
              <div class="h-10 w-10 shrink-0 overflow-hidden rounded-lg bg-daun-soft">
                @if ($p->imageUrl())<img src="{{ $p->imageUrl() }}" alt="" class="h-full w-full object-cover">@endif
              </div>
              <span class="font-medium">{{ $p->name }}</span>
            </div>
          </td>
          <td class="td text-ink/70">Rp {{ number_format($p->cost_price, 0, ',', '.') }}</td>
          <td class="td">Rp {{ number_format($p->price, 0, ',', '.') }}</td>
          <td class="td">
            <span class="font-semibold {{ $p->stock == 0 ? 'text-red-700' : ($p->stock <= 5 ? 'text-amber-700' : '') }}">{{ $p->stock }}</span>
          </td>
          <td class="td">
            <div class="flex justify-end gap-2">
              <a href="{{ route('seller.products.edit', $p) }}" class="btn-ghost !px-3 !py-1.5">Ubah</a>
              <form method="POST" action="{{ route('seller.products.destroy', $p) }}" onsubmit="return confirm('Hapus {{ addslashes($p->name) }}?')">
                @csrf @method('DELETE')
                <button class="btn-danger !px-3 !py-1.5">Hapus</button>
              </form>
            </div>
          </td>
        </tr>
      @empty
        <tr><td colspan="5" class="px-4 py-10 text-center text-sm text-ink/50">Belum ada barang. Tambahkan barang pertama.</td></tr>
      @endforelse
    </tbody>
  </table>
</div>
<div class="mt-4">{{ $products->links() }}</div>
@endsection
