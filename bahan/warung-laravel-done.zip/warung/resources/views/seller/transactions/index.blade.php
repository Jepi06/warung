@extends('layouts.seller')
@section('title', 'Kas')

@section('content')
<div class="mb-4 flex flex-wrap items-center justify-between gap-3">
  <h1 class="text-xl font-bold">Kas masuk &amp; keluar</h1>
  <div class="flex gap-2">
    <a href="{{ route('seller.transactions.create', ['type' => 'out']) }}" class="btn-primary">Catat pengeluaran</a>
    <a href="{{ route('seller.transactions.create', ['type' => 'in']) }}" class="btn-ghost">Catat pemasukan lain</a>
  </div>
</div>

<form method="GET" class="mb-4 flex flex-wrap items-end gap-3">
  <div><label class="label" for="from">Dari</label><input id="from" type="date" name="from" value="{{ $from->toDateString() }}" class="input"></div>
  <div><label class="label" for="to">Sampai</label><input id="to" type="date" name="to" value="{{ $to->toDateString() }}" class="input"></div>
  <div>
    <label class="label" for="type">Jenis</label>
    <select id="type" name="type" class="input">
      <option value="">Semua</option>
      <option value="in" @selected($type === 'in')>Pemasukan</option>
      <option value="out" @selected($type === 'out')>Pengeluaran</option>
    </select>
  </div>
  <button class="btn-ghost">Tampilkan</button>
</form>

<div class="mb-4 grid gap-3 sm:grid-cols-3">
  <div class="panel p-4"><div class="text-sm text-ink/60">Pemasukan</div><div class="text-xl font-bold text-daun">Rp {{ number_format($income, 0, ',', '.') }}</div></div>
  <div class="panel p-4"><div class="text-sm text-ink/60">Pengeluaran</div><div class="text-xl font-bold text-red-700">Rp {{ number_format($expense, 0, ',', '.') }}</div></div>
  @php $diff = $income - $expense; @endphp
  <div class="panel p-4"><div class="text-sm text-ink/60">Selisih</div><div class="text-xl font-bold {{ $diff < 0 ? 'text-red-700' : '' }}">{{ $diff < 0 ? '−' : '' }}Rp {{ number_format(abs($diff), 0, ',', '.') }}</div></div>
</div>

<div class="panel overflow-x-auto">
  <table class="w-full">
    <thead class="border-b border-garis"><tr>
      <th class="th">Tanggal</th><th class="th">Keterangan</th><th class="th text-right">Jumlah</th><th class="th"></th>
    </tr></thead>
    <tbody class="divide-y divide-garis">
      @forelse ($transactions as $t)
        <tr>
          <td class="td whitespace-nowrap text-ink/70">{{ $t->date->format('d M Y') }}</td>
          <td class="td">
            {{ $t->description }}
            @if ($t->product && $t->qty)
              <span class="ml-1 rounded-full bg-daun-soft px-2 py-0.5 text-xs font-semibold text-daun-dark">+{{ $t->qty }} stok {{ $t->product->name }}</span>
            @endif
            @if ($t->order_id)
              <a href="{{ route('seller.orders.show', $t->order_id) }}" class="ml-1 text-xs text-daun hover:underline">lihat pesanan</a>
            @endif
          </td>
          <td class="td whitespace-nowrap text-right font-semibold {{ $t->type === 'in' ? 'text-daun' : 'text-red-700' }}">
            {{ $t->type === 'in' ? '+' : '−' }} Rp {{ number_format($t->amount, 0, ',', '.') }}
          </td>
          <td class="td text-right">
            @unless ($t->order_id)
              <form method="POST" action="{{ route('seller.transactions.destroy', $t) }}" onsubmit="return confirm('Hapus catatan ini?')">
                @csrf @method('DELETE')
                <button class="text-sm text-red-700 hover:underline">Hapus</button>
              </form>
            @endunless
          </td>
        </tr>
      @empty
        <tr><td colspan="4" class="px-4 py-10 text-center text-sm text-ink/50">Belum ada transaksi di rentang tanggal ini.</td></tr>
      @endforelse
    </tbody>
  </table>
</div>
<div class="mt-4">{{ $transactions->links() }}</div>
@endsection
