@extends('layouts.seller')
@section('title', 'Ringkasan')

@section('content')
@php $profit = $income - $expense; @endphp

<form method="GET" class="mb-5 flex flex-wrap items-end gap-3">
  <div>
    <label class="label" for="from">Dari</label>
    <input id="from" type="date" name="from" value="{{ $from->toDateString() }}" class="input">
  </div>
  <div>
    <label class="label" for="to">Sampai</label>
    <input id="to" type="date" name="to" value="{{ $to->toDateString() }}" class="input">
  </div>
  <button class="btn-ghost">Tampilkan</button>
</form>

<div class="grid gap-3 sm:grid-cols-3">
  <div class="panel p-4">
    <div class="text-sm text-ink/60">Pemasukan</div>
    <div class="mt-1 text-2xl font-bold text-daun">Rp {{ number_format($income, 0, ',', '.') }}</div>
  </div>
  <div class="panel p-4">
    <div class="text-sm text-ink/60">Pengeluaran</div>
    <div class="mt-1 text-2xl font-bold text-red-700">Rp {{ number_format($expense, 0, ',', '.') }}</div>
  </div>
  <div class="panel p-4 {{ $profit < 0 ? 'border-red-300' : 'border-daun/40' }}">
    <div class="text-sm text-ink/60">Selisih (laba kotor)</div>
    <div class="mt-1 text-2xl font-bold {{ $profit < 0 ? 'text-red-700' : '' }}">
      {{ $profit < 0 ? '−' : '' }}Rp {{ number_format(abs($profit), 0, ',', '.') }}
    </div>
  </div>
</div>

<div class="mt-6 grid gap-6 lg:grid-cols-2">
  <section>
    <div class="mb-2 flex items-center justify-between">
      <h2 class="font-semibold">Pesanan menunggu ({{ $pendingCount }})</h2>
      <a href="{{ route('seller.orders.index') }}" class="text-sm text-daun hover:underline">Lihat semua</a>
    </div>
    <div class="panel divide-y divide-garis">
      @forelse ($pendingOrders as $o)
        <a href="{{ route('seller.orders.show', $o) }}" class="flex items-center justify-between px-4 py-3 hover:bg-daun-soft/50">
          <div>
            <div class="font-medium">#{{ $o->id }} · {{ $o->customer_name }}</div>
            <div class="text-xs text-ink/50">{{ $o->created_at->diffForHumans() }}</div>
          </div>
          <div class="text-sm font-semibold">Rp {{ number_format($o->total, 0, ',', '.') }}</div>
        </a>
      @empty
        <p class="px-4 py-6 text-center text-sm text-ink/50">Belum ada pesanan baru.</p>
      @endforelse
    </div>
  </section>

  <section>
    <div class="mb-2 flex items-center justify-between">
      <h2 class="font-semibold">Stok menipis</h2>
      <a href="{{ route('seller.products.index') }}" class="text-sm text-daun hover:underline">Kelola barang</a>
    </div>
    <div class="panel divide-y divide-garis">
      @forelse ($lowStock as $p)
        <a href="{{ route('seller.products.edit', $p) }}" class="flex items-center justify-between px-4 py-3 hover:bg-daun-soft/50">
          <span class="font-medium">{{ $p->name }}</span>
          <span class="rounded-full px-2.5 py-0.5 text-xs font-semibold {{ $p->stock == 0 ? 'bg-red-100 text-red-700' : 'bg-kunyit-soft text-amber-800' }}">
            {{ $p->stock == 0 ? 'Habis' : 'Sisa ' . $p->stock }}
          </span>
        </a>
      @empty
        <p class="px-4 py-6 text-center text-sm text-ink/50">Semua stok aman.</p>
      @endforelse
    </div>
  </section>
</div>
@endsection
