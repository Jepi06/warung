@extends('layouts.seller')
@section('title', 'Pesanan #' . $order->id)

@section('content')
<a href="{{ route('seller.orders.index') }}" class="text-sm text-daun hover:underline">← Semua pesanan</a>

<div class="mt-2 mb-4 flex flex-wrap items-center gap-3">
  <h1 class="text-xl font-bold">Pesanan #{{ $order->id }}</h1>
  @include('partials.status', ['status' => $order->status])
</div>

<div class="grid gap-6 lg:grid-cols-3">
  <div class="panel lg:col-span-2">
    <table class="w-full">
      <thead class="border-b border-garis"><tr>
        <th class="th">Barang</th><th class="th">Harga</th><th class="th">Jumlah</th><th class="th text-right">Subtotal</th>
      </tr></thead>
      <tbody class="divide-y divide-garis">
        @foreach ($order->items as $i)
          @php $stok = $i->product?->stock; @endphp
          <tr>
            <td class="td font-medium">
              {{ $i->product_name }}
              @if ($order->status === 'pending')
                <div class="text-xs {{ ($stok ?? 0) < $i->qty ? 'text-red-600' : 'text-ink/50' }}">
                  {{ $i->product ? 'Stok sekarang ' . $stok : 'Barang sudah dihapus' }}
                </div>
              @endif
            </td>
            <td class="td">Rp {{ number_format($i->price, 0, ',', '.') }}</td>
            <td class="td">{{ $i->qty }}</td>
            <td class="td text-right">Rp {{ number_format($i->subtotal, 0, ',', '.') }}</td>
          </tr>
        @endforeach
      </tbody>
      <tfoot class="border-t border-garis">
        <tr>
          <td colspan="3" class="td text-right font-semibold">Total</td>
          <td class="td text-right text-base font-bold">Rp {{ number_format($order->total, 0, ',', '.') }}</td>
        </tr>
      </tfoot>
    </table>
  </div>

  <div class="space-y-4">
    <div class="panel p-4 text-sm">
      <div class="text-ink/60">Pembeli</div>
      <div class="font-semibold">{{ $order->customer_name }}</div>
      @if ($order->customer_phone)
        <a href="{{ $order->customerWaUrl() }}" target="_blank" class="text-daun hover:underline">{{ $order->customer_phone }} (chat WA)</a>
      @endif
      @if ($order->note)
        <div class="mt-3 text-ink/60">Catatan</div><div>{{ $order->note }}</div>
      @endif
      <div class="mt-3 text-ink/60">Dipesan</div><div>{{ $order->created_at->format('d M Y, H:i') }}</div>
      @if ($order->confirmed_at)
        <div class="mt-3 text-ink/60">Diserahkan</div><div>{{ $order->confirmed_at->format('d M Y, H:i') }}</div>
      @endif
    </div>

    @if ($order->status === 'pending')
      <div class="panel space-y-2 p-4">
        <form method="POST" action="{{ route('seller.orders.confirm', $order) }}"
              onsubmit="return confirm('Barang sudah diserahkan ke pembeli? Stok akan dikurangi.')">
          @csrf
          <button class="btn-primary w-full">Barang sudah diserahkan</button>
        </form>
        <form method="POST" action="{{ route('seller.orders.cancel', $order) }}" onsubmit="return confirm('Batalkan pesanan ini?')">
          @csrf
          <button class="btn-danger w-full">Batalkan pesanan</button>
        </form>
        <p class="text-xs text-ink/50">Stok berkurang dan pemasukan tercatat setelah kamu menekan tombol hijau.</p>
      </div>
    @endif
  </div>
</div>
@endsection
