@extends('layouts.seller')
@section('title', 'Pesanan')

@section('content')
<h1 class="mb-4 text-xl font-bold">Pesanan</h1>

<div class="mb-4 flex flex-wrap gap-1 text-sm font-medium">
  @foreach (['pending' => 'Menunggu', 'completed' => 'Selesai', 'cancelled' => 'Dibatalkan', 'all' => 'Semua'] as $key => $label)
    <a href="{{ route('seller.orders.index', ['status' => $key]) }}"
       class="rounded-lg px-3 py-1.5 {{ $status === $key ? 'bg-daun text-white' : 'bg-white border border-garis hover:bg-daun-soft' }}">{{ $label }}</a>
  @endforeach
</div>

<div class="panel overflow-x-auto">
  <table class="w-full">
    <thead class="border-b border-garis"><tr>
      <th class="th">No.</th><th class="th">Pembeli</th><th class="th">Waktu</th>
      <th class="th">Total</th><th class="th">Status</th><th class="th"></th>
    </tr></thead>
    <tbody class="divide-y divide-garis">
      @forelse ($orders as $o)
        <tr>
          <td class="td font-medium">#{{ $o->id }}</td>
          <td class="td">{{ $o->customer_name }}<div class="text-xs text-ink/50">{{ $o->items_count }} jenis barang</div></td>
          <td class="td text-ink/70">{{ $o->created_at->format('d M, H:i') }}</td>
          <td class="td font-semibold">Rp {{ number_format($o->total, 0, ',', '.') }}</td>
          <td class="td">@include('partials.status', ['status' => $o->status])</td>
          <td class="td text-right"><a href="{{ route('seller.orders.show', $o) }}" class="btn-ghost !px-3 !py-1.5">Buka</a></td>
        </tr>
      @empty
        <tr><td colspan="6" class="px-4 py-10 text-center text-sm text-ink/50">Tidak ada pesanan.</td></tr>
      @endforelse
    </tbody>
  </table>
</div>
<div class="mt-4">{{ $orders->links() }}</div>
@endsection
