<!DOCTYPE html>
<html lang="id">
<head>
  @include('partials.head')
  <title>@yield('title', 'Penjual') · {{ config('shop.name') }}</title>
</head>
<body class="min-h-screen bg-kertas font-sans text-ink antialiased">
@php
  $pending = \App\Models\Order::where('status', 'pending')->count();
  $nav = [
    ['seller.dashboard', 'Ringkasan', 'seller.dashboard'],
    ['seller.orders.index', 'Pesanan', 'seller.orders.*'],
    ['seller.products.index', 'Barang', 'seller.products.*'],
    ['seller.stock.index', 'Stok & harga', 'seller.stock.*'],
    ['seller.transactions.index', 'Kas', 'seller.transactions.*'],
  ];
@endphp
  <header class="border-b border-garis bg-white">
    <div class="mx-auto flex max-w-5xl flex-wrap items-center gap-x-6 gap-y-2 px-4 py-3">
      <a href="{{ route('seller.dashboard') }}" class="text-lg font-bold tracking-tight text-daun">{{ config('shop.name') }}</a>
      <nav class="flex flex-1 flex-wrap items-center gap-1 text-sm font-medium">
        @foreach ($nav as [$route, $label, $pattern])
          <a href="{{ route($route) }}"
             class="rounded-lg px-3 py-1.5 {{ request()->routeIs($pattern) ? 'bg-daun text-white' : 'text-ink/70 hover:bg-daun-soft' }}">
            {{ $label }}
            @if ($route === 'seller.orders.index' && $pending > 0)
              <span class="ml-1 rounded-full bg-kunyit px-1.5 text-xs font-bold text-ink">{{ $pending }}</span>
            @endif
          </a>
        @endforeach
      </nav>
      <div class="flex items-center gap-3 text-sm">
        <a href="{{ route('shop') }}" class="text-ink/60 hover:text-ink" target="_blank">Lihat toko</a>
        <form method="POST" action="{{ route('seller.logout') }}">@csrf
          <button class="text-ink/60 hover:text-ink">Keluar</button>
        </form>
      </div>
    </div>
  </header>
  <main class="mx-auto max-w-5xl px-4 py-6">
    @include('partials.flash')
    @yield('content')
  </main>
</body>
</html>
